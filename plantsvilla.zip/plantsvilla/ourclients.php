<!DOCTYPE html>
<?php 
include('functions/include.php');
?>
<html>
<head>

<title>Feedback</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>
<ul id="nav">
        <li><a href="index.php">Home</a></li>
             <!--<li><a href="services.php"><i>Services</i></a></li>-->
		<li><a  href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="nseasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               

                <li><a href="pg2.php"><i>Contact us</i></a></li>
				<li class="current"><a href="ourclients.php"><i>Feedback</i></a></li>
		
                   
         </li>
		 <li><a href="login.php"><i>Login</i></a></li>
		 <li><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
		 <!--<li class="current"style="float : right"><i><a href="logout.php">Log Out</a></i></li>-->
	</ul>

	<div id="terms">
	 <div id="where">
   <p id="where1">
   Give Us Feedback
	</p>
	</div>
	<div id="client">
   <form action="ourclients.php" method="post" enctype="multpart/form-data">
<center>
<h1><center> Feedback Form </center></h1>
<table>

<tr>

<td>Enter your name*

<td><input type="text" placeholder="Enter Your Name" name="name1" required><br><br>
<tr>
<td>Enter E-Mail ID*
<td><input type ="email" placeholder="abc@abc.com" name="email1" required>

<br><br>
<tr>
<td>Enter Phone No.*
<td><input type="text" placeholder="**********" name="phone1" required><br><br>


<tr>
<td><fieldset>
<legend>  Rate Us!   </legend>
<input type=radio name=r1 value="1" required>1<br>
<input type=radio name=r1 value="2" required>2<br>
<input type=radio name=r1 value="3" required>3<br>
<input type=radio name=r1 value="4" required>4<br>
<input type=radio name=r1 value="5" required>5<br>
</fieldset><br><br>

<tr>
<td colspan="2"><center><input type="submit" name="insert_post" value="submit">
</table>
</center>
</form>

   </div>
   </div>
   <div id="links">
<a href="about.php"><div id="social"><span>Connect with us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
 <div id="footer1">Copyright @ 2016-2017.The Plants Villa. All rights reserved. </div>
 
	
   
	</div>
	
	
	</body>
	</html>
	
<?php

	if(isset($_POST['insert_post'])){
	$name_tmp = $_POST['name1'];
	$email_tmp = $_POST['email1'];
	$phone_tmp = $_POST['phone1'];
	$radio_tmp = $_POST['r1'];
	
	$insert_feedback = "insert into feedback (name,email_id,phone_no,rating) 
	values('$name_tmp','$email_tmp','$phone_tmp','$radio_tmp')";
	
	$insert_fed = mysqli_query($con, $insert_feedback);
	if($insert_fed){
		
		echo "<script>alert('Feedback sent')</script>";
		echo "<script>window.open('ourclients.php','_self')</script>";
	}
	}

?>