<html>
<head>
<title>Conditions</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>
<ul id="nav">
        <li><a href="index.php">Home</a></li>
             <!--<li><a href="services.html"><i>Services</i></a></li>-->
		<li><a  href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="nseasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               
		
                <li><a href="pg2.php"><i>Contact us</i></a></li>
				<li><a href="ourclients.php"><i>Feedback</i></a></li>
		
                   
         </li>
		 <li><a href="login.php"><i>Login</i></a></li>
		 <li><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
		 <!--<li class="current"style="float : right"><i><a href="logout.php">Log Out</a></i></li>-->
	</ul>

   <div id="terms">
   <div id="where">
   <p id="where1">
   TERMS AND CONDITIONS
	</p>
   </div>
 
   <br>
   <div id="termsncond">
   <p id="termsncond">
   This policy describes the personal information we collect on  www.xxxx.com  and any other authorized sites, services and tools where this
   policy appears (collectively, this "Site"), how we use it, and when we share it with third parties. 
   Program terms applicable to Programs not described herein or in the Terms of Use Statement provide additional information about information collected 
   related to that Program(s) and how it is used in connection with the applicable Program. This policy applies only to information collected via this Site, 
   and unless otherwise specifically described herein or in any Program terms, does not apply to information collected offline 
   (including but not limited to information you may provide over the phone, via fax, or when visiting a Flavours  bakery-cafe or any other website of
   Flavours  or on third party sites) (see Third Party Sites section below).
   Please note that not all of the features/functionality described are available on or through each portion of the Site.
<br/><br/>
By using this Site, you agree to this Privacy Policy and to the Terms of Use statement ("Statement") governing its use and Program terms applicable 
to various Programs. If you have questions, comments or concerns about this Privacy Policy, please Contact Us. Be sure to check this page periodically for 
updates, as your continued use of this Site and/or participation in any Program signifies your acceptance of any changed terms.
<br/></br>
<span>
Information Collected and How It Is Used</span>
<br/><br/>
Information is collected about you (directly and/or through the activities of third party suppliers and service providers ("suppliers") and/or franchisees)
 from various sources, including without limitation the following:
<br/><br/>
1.information you provide when you Contact Us through this Site,
<br/><br/>2.information you provide on the Program/account registration and other online pages, surveys, or other submission through this Site and/or in connection with Programs and services available through this Site,
<br/><br/>3.information recorded as a result of your interaction with us and/or franchisees and/or use of the Site (including without limitation information we receive when you use your Program member card(s), historical sales information, information about your location and the device you are using, through this Site or any other website or in any other manner),
<br/><br/>4.information you provide when you respond to surveys conducted by or on behalf of us and/or franchisees,
<br/><br/>5.information we gather about you through our marketing activities (see the Site Usage and Targeted Marketing Information section below),
<br/><br/>6.information we collect about you from outside of this Site, including without limitation information we receive from you in person and/or from third parties (including without limitation from franchisees and referrals from third parties),
<br/><br/>7.information we collect about you from third parties in order to supplement our existing information about you, and
<br/><br/>8.as described elsewhere in this Privacy Policy and applicable Program terms.
<br/><br/>The information collected may be combined with other information and may be used and disclosed in a number of ways by us 
(directly and/or through the activities of franchisees and/or supplier(s)), to help us better understand and serve our customers, or as otherwise described,
 including without limitation as described below.
 

<br/><br/>1.To provide you with, or otherwise respond to your requests for, information and/or services, including but not limited to e-newsletters, access to our webcasts concerning quarterly earnings, marketing and other programs, identifying a Flavours  bakery-cafe location and letting you know if you qualify for an Operation Donation program.
<br/><br/>2.To administer Programs and services, including without limitation providing you with services and Program benefits, features and related communications, to verify your participation in the Program or service, to process orders placed and applicable payments, to track submissions, to make your historical ordering information available to you for your future ordering purposes. Note that third party information you provide (for example, your friend in a forward-to-a-friend program) may be maintained in connection with your submission.
<br/><br/>3.To provide you with information about new products or services, events in our bakery-cafes, events that Flavours or its franchisee�s sponsors, including but not limited to contests, sweepstakes and surveys, and other special offers and marketing programs, which may include information about our affiliated company(ies), franchisees and/or other programs with which any of us or them are involved.
<br/><br/>4.To enhance our customers' and Site users� experiences in our bakery-cafes, on this Site or in a Program and enhance the sales efforts of Flavours and/or its Franchisees.
<br/><br/>5.To provide Site and Program functionality.
<br/><br/>6.To conduct research and analysis and to otherwise measure the effectiveness of this Site, our online and offline marketing efforts and to develop and implement products, services, and marketing programs. This analysis may include combining personal data drawn from online and offline sources.
<br/><br/>7.To work with third parties to append data to our records or enable other parties to append your non-personal data to their records.
<br/><br/>8.In connection with certain submissions by you as described in the Statement.
<br/><br/>9.To coordinate Program activities and communications with other marketing programs conducted by us and/or franchisees.
<br/><br/>10.To process your online job application and related information.
<br/><br/>11.For purposes of targeted or customized advertising or messaging to you, as further described in Site Usage and Targeted Marketing Information.
<br/><br/>12.To learn more about potential investors in our company, and to allow you to ask questions and receive responses during our webcasts for investors.
<br/><br/>13.As otherwise described in this Privacy Policy, the Terms of Use statement and/or Program terms or on this Site at the time such information is collected.
<br/><br/>We do not sell or rent to third parties any of the personal information that you provide to us through this Site, 
however, we do provide your information to our suppliers who are performing services for us, but we do not authorize third parties unaffiliated with Flavours
  to make independent use of your personal information for their own benefit, such as for their own direct marketing, without your consent. 
 Additionally, aggregated and/or anonymous information about our users may be shared with any number of third parties. 
 Additionally, we may share your information with our affiliates, franchisees, lenders, investors and/or third party providers. 
 
 In addition to the uses described above, we share information with these third parties primarily to respond to your specific request or 
 to obtain their service and/or advice on how to improve our business. Your personal information may be transferred to and within the United States, 
 and certain of your personal information may be transferred to other countries. Please also see Security of Your Personal Information below.
<br/><br/>

<span>Site Usage and Targeted Marketing Information</span>
<br/><br/>
<br/><br/>Like most web sites, this Site gathers traffic patterns, site usage information and similar data. This usage data may identify you individually and we may associate it with other personal information that we collect from you on this Site and related to any Program(s) you participate in and as otherwise described in this Privacy Policy (see Information Collected and How It Is Used section of this privacy policy and any applicable individual Program terms for more details on how this information is used). This usage data may also be used in anonymous and/or aggregated form. We may share anonymous and/or aggregated statistics about visitors to this Site with others outside our Company, and we may allow third-parties to collect and aggregate non-personal information through this Site and/or supplier sites accessible from or through this Site.

<br/><br/>This Site may use cookies, pixels, web beacons (described below) or other similar technology to enhance the browsing and usage experience on this Site. The information captured about your activities on this Site will make it possible for us, among other things, (i) to speed navigation and provide you with custom tailored content; (ii) to remember information you gave to us so you don't have to re-enter it each time you visit this Site; (iii) to monitor the effectiveness of certain of our marketing campaigns; (iv) to monitor total number of visitors, pages viewed, web address you came from and type of browser you are using, and (v) enforce limitations on downloads described for on-line coupons and other similar offers.

<br/><br/>We may from time to time use your information and third party service providers to implement and evaluate our marketing activities and programs, including without limitation activities on our Site and to engage in targeted and personalized online advertising on third party websites or other online or offline services operated by third parties. This marketing may be completed using data collected about you over time in connection with Programs you participate in, on this Site and other sites on the Internet, from our other marketing activities and programs, and from third parties with whom we work. This data may be collected on an individual basis, such as through information you have provided to us on this Site or through a Program, or based on the use of cookies, pixels, web beacons and other technology, as described below. This information may also be available to and/or shared with the third party service providers and others outside our Company on an anonymous basis for their own business purposes. For information about opting out of our third party service provider cookies/pixels/web beacons and certain other targeted advertising, please visit the Network Advertising Initiative website  networkadvertising.org  and aboutads.info/consumers.

"Cookies" are small files or records that are stored on your computer's hard drive when you visit a website. To opt out of receiving most cookies related to this Site, including cookies used for targeted advertising, you can clear your browser(s) of all existing cookies, and set your browser(s) to refuse cookies. The "help" functionality of your browser(s) will explain how to do this. If you refuse cookies, your experience on this Site, some Programs, and some of our online advertising may be affected � for example you may not be able to utilize all of the functions on this Site. If you delete your cookies, change browsers or use a different computer, any opt-out cookie may no longer work and you will have to opt-out again.  We may also use a "pixel" or "web beacon" which is a line of code used by a website or third party ad server to cause a cookie to track a user�s activity on particular sites and/or using particular advertising/links, for example, to record that a user has visited a particular webpage and to collect other information about that user on that site, including without limitation the IP address of the computer (and therefore infer information, such as geolocation), web pages being viewed, date/time viewed, and user activity on a particular page.
<br/><br/>
<span>Security of Your Personal Information</span>
<br/><br/>
Flavours  maintains reasonable physical, electronic and procedural safeguards to protect your personal information. Unfortunately though, we can't guarantee that any safeguards or security measures will be sufficient to prevent a security problem. If you believe your account(s) have been compromised, please immediately Contact Us and take immediate action to remove the credit card, Flavours gift card or other payment information associated with your account(s).  Personal information and non-personal information are stored on computers and servers located in the United States. The United States may not offer a level of privacy protection for personal information as great as that offered in other jurisdictions. Therefore the disclosure of personal information is at your own risk. We make no representation that the practices described in this policy are compliant with laws outside of the United States that apply to the collection, security, use and disclosure of personal information.  Email submissions over the Internet may not be secure. Please consider this fact before emailing any personal or confidential information.
<br/><br/>
<span>Transfer of Assets or Business</span>
<br/><br/>
In the event of a transfer or sale of some or all of our business or assets, Flavours  may disclose your personal information to those involved in such a transfer or sale of business or assets.
<br/><br/>
<span>Miscellaneous</span>
<br/><br/>
<br/>This Privacy Policy is subject to, and incorporated by reference into, the Statement.
<br/>Capitalized terms referenced in this Privacy Policy but not defined herein shall have the same meaning as identified in the Statement.
<br/><br/>
<span>For More Information</span>
<br/><br/>
If you have any questions regarding our Privacy Policy, please Contact Us or write to us at:
<br/>
<br/>Customer Resource Group?
<br/>Plants Villa
<br/>3630 S. Geyer Road
<br/>?St. Louis, MO 63127
<br/><br/>
� 2016-2017.The Plants Villa. All rights reserved.
<br/>
</p></div>
	</div>
	
	<div id="links">
<a href="about.php"><div id="social"><span>Connect with us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
 <div id="footer1">Copyright @ 2016-2017.The Plants Villa . All rights reserved. </div>

	</div>

   
  

</body>
</html>
