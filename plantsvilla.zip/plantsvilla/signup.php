<!DOCTYPE>
<?php 
include('functions/include.php');
?>
<html>
<head>
<title>signup</title>

<link rel="stylesheet" href="css/style.css" type="text/css" >
<link rel="stylesheet" href="css/aboutus.css" type="text/css" >
<link rel="stylesheet" href="css/final1.css" type="text/css" >
<link rel="stylesheet" href="css/menu1.css" type="text/css" >
<link rel="stylesheet" href="css/packages.css" type="text/css" >
<link rel="stylesheet" href="css/tab.css" type="text/css" >
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>
<ul id="nav">
        <li><a href="index.php">Home</a></li>
        
		<li><a href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="nseasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               

                <li><a href="pg2.php"><i>Contact us</i></a></li>
				<li><a href="ourclients.php"><i>Feedback</i></a></li>
                   
         </li>
		 <li><a href="login.php"><i>Login</i></a></li>
		 <li  class="current"><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
		 <!--<li class="current"style="float : right"><i><a href="logout.php">Log Out</a></i></li>-->
	</ul>

	<div id="terms">
	 <div id="where">
   <p id="where1">
Sign Up for Free
	</p>
	</div>
	<div id="client">
   <form action="signup.php" method="post" enctype="multpart/form-data">
<center>

<table>

<tr>

<td> First Name<span class="req">*</span>

<td><input type="text" name="fname" required /><br><br>
<tr>
<td>Last Name<span class="req">*</span>
<td> <input type="text" name="lname" required/><br><br>

<br><br>
<tr>
<td>Email Address<span class="req">*</span>
<td><input type="email" name="email2" required><br><br>
<tr>
<td>Phone Number<span class="req">*</span>
<td><input type="text" name="phone_no" required><br><br>

<tr>
<td>  Set A Password<span class="req">*</span>

<td><input type="password" name="pass" required/><br><br>

<tr>
<td colspan=2><center><input type="submit" name="sign_up" value="Sign Up">
</table>
</center>
</form>

   </div>
   </div>
   <div id="links">
<a href="about.php"><div id="social"><span>Connect with us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
 <div id="footer1">Copyright @ 2016-2017.The Plants Villa. All rights reserved. </div>
 
	
   
	</div>
	
	
	</body>
	</html>

<?php

	if(isset($_POST['sign_up'])){
	$fname_tmp = $_POST['fname'];
	$lname_tmp = $_POST['lname'];
	$email_tmp = $_POST['email2'];
	$phone_tmp = $_POST['phone_no'];
	$pass_tmp = $_POST['pass'];
	
	$insert_cust = "insert into customers (fname,lname,phone_no,email,password) 
	values('$fname_tmp','$lname_tmp','$phone_tmp','$email_tmp','$pass_tmp')";
	
	$insert_c = mysqli_query($con, $insert_cust);
	if($insert_c){
		
		echo "<script>alert('Sign up Sucessful')</script>";
		echo "<script>window.open('login.php','_self')</script>";
	}
	}

?>






