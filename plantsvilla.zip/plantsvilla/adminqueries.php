<!DOCTYPE>
<?php 
include('functions/include.php');
?>
<html>
<head><title>Logged In</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body>
<?php
session_start();
$myusername = $_SESSION['Message1'];
$sql = mysqli_query($con,"SELECT fname FROM admin WHERE email = '$myusername'");
$result = mysqli_fetch_row($sql);
echo "Admin ";
echo $result[0];
?>
<br>
<ul id="nav">
<li><a href="admin.php">Orders</a></li>
<li class="current"><a href="adminqueries.php">Queries</a></li>
<li><a href="logout.php">Logout</a><li>
</ul>
<center>
<h1><center>Queries</center></h1>

<?php

$result = mysqli_query($con,"SELECT * FROM queries order by id DESC");

echo "<table border='1'>
<tr>
<th>Query Id</th>
<th>Customers Name</th>
<th>Customers Email</th>
<th>Date</th>
<th>Query</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['id'] . "</td>";
echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['email_id'] . "</td>";
echo "<td>" . $row['date'] . "</td>";
echo "<td>" . $row['query'] . "</td>";
echo "</tr>";
}
echo "</table>";

mysqli_close($con);
?>

</center>




</body>
</html>
