<html>
<head>
<title>Contact us</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>
<ul id="nav">
        <li><a href="index.php">Home</a></li>
             <!--<li><a href="services.php"><i>Services</i></a></li>-->
		<li><a  href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="nseasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               
		
                <li class="current"><a href="pg2.php"><i>Contact us</i></a></li>
				<li><a href="ourclients.php"><i>Feedback</i></a></li>
		
                   
         </li>
		 <li><a href="login.php"><i>Login</i></a></li>
		 <li><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
		 <!--<li class="current"style="float : right"><i><a href="logout.php">Log Out</a></i></li>-->
	</ul>


<div id="info">
	<img id="locations"src="img/locationsimg.jpg">
	</div>
	<div id="info1">
	<div id="where">
	<p id="where1">
	Where can you find us!</p>
	</div>
	<div id="info2">
		<p id="how1">
	Sion<br><br>
	</p>
	<p id="how2">
	<label>Address   :</label>   Punjabi Camp, G.T.B Nagar, Sion, 
Mumbai 400037<br/>
<label>Contact Number :</label>
 	+91 22 2401 2098/ 2401 5103<br><br><br>
	</p>
	<p id="how1">
	Bandra<br><br>
	</p>
	<p id="how2">
	<label>Address :</label>
 	Chinese Court, Jn. of 16th & 33rd T.P.S Road, Bandra (W) Mumbai 400050
	<label>Contact Number :</label>
 	  <br> +91 22 2600 2164/ 2600 4395<br><br><br>
	</p>
	<p id="how1">
	Thane<br><br>
	</p>
	<p id="how2">
	<label>Address :</label>
 	Adishankrachary Marg,
Near Punch Kutir Bus Stop, JVLR,
Powai - Mumbai<br>
<label>Contact Number :</label>
 	+91 22 2570 8688/ 89
	</p>
	</div>
	
	</div>

<div id="links">
<a href="about.php"><div id="social"><span>Know About us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
 <div id="footer1">Copyright @ 2016-2017.The Plants Villa. All rights reserved. </div>

	</div>

</body>
</html>
