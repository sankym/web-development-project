<html>
<head>
<title>Plants Villa</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px" border-radius="20px"/>
</div>
    <ul id="nav">
        <li class="current"><a href="index.php">Home</a></li>
		<li><a  href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="nseasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               
				
                <li><a href="pg2.php"><i>Contact us</i></a></li>
				<li><a href="ourclients.php"><i>Feedback</i></a></li>
		
                   
         </li>
		 <li><a href="login.php"><i>Login</i></a></li>
		 <li><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
	</ul>

<div id="banner"><iframe src="simple-slider.source.html" width="1214px" height="390" scrolling="no"></iframe>
	</div>
<div id="aboutus">
<div id="leftaboutus">
<img src="img/images/leftaboutus1.jpg" width="100%" height="350px" /> 
</div>
<div id="rightaboutus">
<p id="writeaboutus">
<span>We are in the business of creating experiences</span>
<br/><br/>
Plants Villa, Inc., is a family of plants that inspire and empower individuals.<br><br> Through FLowering, Non Flowering, Aquatic and Decoratives, Plants Villa, Inc., is an international company that sells plants with reasonable price and at very low cost as compaared to global market,decorative products are also available. We manufacture and distribute our products over 2000 specialty stores in the U.S., and Canada, and e-commerce sites and is still growing.

<br><br>All of products are well produced by professionals with the utmost

</p>
</div>

</div>
<div id="links">
<a href="about.php"><div id="social"><span>Connect with us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
 <div id="footer1">Copyright @ 2016-2017.The HAS. All rights reserved. </div>
	</div>

</body>
</html>
