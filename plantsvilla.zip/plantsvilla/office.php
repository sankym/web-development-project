<html>
<head>
<title>office</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
<script src="tabcontent.js" type="text/javascript"></script>
</head>
<body >
<div class="example" >

<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>
<ul id="nav">
        <li><a href="index.php">Home</a></li>
             <!--<li><a href="services.php"><i>Services</i></a></li>-->
		<li class="current"><a  href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="nseasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               
			
                <li><a href="pg2.php"><i>Contact us</i></a></li>
				<li><a href="ourclients.php"><i>Feedback</i></a></li>
		
                   
         </li>
		 <li><a href="login.php"><i>Login</i></a></li>
		 <li><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
		 <!--<li class="current"style="float : right"><i><a href="logout.php">Log Out</a></i></li>-->
	</ul>

	
	<div id="menu1">
<div id="title">
   <p id="where1">
   Office
	</p>
   </div>


        <div class="tabcontents">
            <div id="view1">
              <div class="img">
			  <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/office1.jpg" width="250" height="210"></a>
 <div class="desc"><center>Exoecaria-Rs 345<br>
   <input type="hidden" name="hid" value="50">
 <input type="submit" value="Order" name="tea"></center></div></form>

</div>
<div class="img">
 <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/office2.jpg" width="250" height="210"></a>
 <div  id="bigbutton" class="desc"><center>Variegated-Rs 670<br>
    <input type="hidden" name="hid" value="51">
 <input type="submit" value="Order" name="coffee"></center></div></form>
</div>
<div class="img"> <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/office3.jpg" width="250" height="210"></a>
 <div class="desc"><center>Hemigraphis-Rs 780<br>
    <input type="hidden" name="hid" value="52">
 <input id="bigbutton" type="submit" value="Order" name="soda"></center></div></form>
</div>
<div class="img"> <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/office4.jpg" width="250" height="210"></a>
 <div class="desc"><center>Colorta-Rs 670<br>
    <input type="hidden" name="hid" value="53">
 <input  id="bigbutton" type="submit" value="Order" name="hot_choclate"></center></div></form>
</div>
<div class="img"> <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/office5.jpg" width="250" height="210"></a>
 <div class="desc"><center>Lithodro-Rs 560<br>
    <input type="hidden" name="hid" value="54">
 <input id="bigbutton" type="submit" value="Order" name="lemonade"></center></div></form>
</div>
<div class="img"> <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/office6.jpg" width="250" height="210"></a>
 <div class="desc"><center>Diffusa-Rs 567<br>
    <input type="hidden" name="hid" value="55">
 <input id="bigbutton" type="submit" value="Order" name="fruit_juice"></center></div></form>
</div>




          </div>
		  <div id="view2">
			<div class="img"> <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/seasonal1.jpg" width="250" height="210"></a>
 <div class="desc"><center>Lantana-Rs 567<br>
    <input type="hidden" name="hid" value="56">
 <input type="submit" value="Order" name="apple_juice"></center></div></form>
</div>
<div class="img"> <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/seasonal4.jpg" width="250" height="210"></a>
 <div class="desc"><center>Vetiver-Rs 456<br>
    <input type="hidden" name="hid" value="57">
 <input type="submit" value="Order" name="orange_juice"></center></div></form>
</div>
<div class="img"> <form action="login.php" method="GET">
 <a href=""><img src="img/seasonal/aquatic3.jpg" width="250" height="210"></a>
 <div class="desc"><center>Ipomea-Rs 457<br>
    <input type="hidden" name="hid" value="58">
 <input type="submit" value="Order" name="pineapple_juice"></center></div></form>
</div>

			</div>

			</div>
		   <ul class="tabs" data-persist="true">
            <li><a href="#view1">Page1</a></li>
            <li><a href="#view2">Page2</a></li>
		 </ul>


 </div>

<div id="links">
<a href="about.php"><div id="social"><span>Connect with us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
<div id="footer1">Copyright @ 2016-2017.The Plants Villa. All rights reserved. </div>
	</div>

</body>
</html>
