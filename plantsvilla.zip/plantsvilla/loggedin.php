<!DOCTYPE>
<?php 
include('functions/include.php');
?>
<html>
<head><title>Logged In</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body>
<?php
session_start();
$myusername = $_SESSION['firstMessage'];
$sql = mysqli_query($con,"SELECT fname FROM customers WHERE email = '$myusername'");
$result = mysqli_fetch_row($sql);
echo "Welcome ";
echo $result[0];
?>
<br>
<ul id="nav">
<li><a href="order.php">Order</a>
<li class="current"><a href="loggedin.php">Queries</a>
<li><a href="logout.php">logout</a>
</ul>
<form action="loggedin.php" method="post" enctype="multpart/form-data">
<center>
<h1><center> Query </center></h1>
<table>

<tr>

<td>Date

<td><input type="date" name="date1" required><br><br>
<tr>

<tr>
<td>Query
<td><textarea rows=10 cols=30 name="query1" required></textarea><br><br>




<tr>
<td colspan="2"><center><input type="submit" name="in_post" value="Send">
</table>
</center>
</form>



</body>
</html>
<?php

	if(isset($_POST['in_post'])){
	$date_tmp = $_POST['date1'];
	$query_tmp = $_POST['query1'];
	$myusername = $_SESSION['firstMessage'];
	$sql = mysqli_query($con,"SELECT fname FROM customers WHERE email = '$myusername'");
	$result = mysqli_fetch_row($sql);
	$insert_query = "insert into queries (name,email_id,query,date) 
	values('$result[0]','$myusername','$query_tmp','$date_tmp')";
	
	$insert_q = mysqli_query($con, $insert_query);
	if($insert_q){
		
		echo "<script>alert('Sent Sucessful')</script>";
		echo "<script>window.open('loggedin.php','_self')</script>";
	}
	}
?>