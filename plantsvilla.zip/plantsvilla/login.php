<!DOCTYPE html>
<?php 
include('functions/include.php');
?>
<html>
<head>
<title>login</title>

<link rel="stylesheet" href="css/style.css" type="text/css" >
<link rel="stylesheet" href="css/aboutus.css" type="text/css" >
<link rel="stylesheet" href="css/final1.css" type="text/css" >
<link rel="stylesheet" href="css/menu1.css" type="text/css" >
<link rel="stylesheet" href="css/packages.css" type="text/css" >
<link rel="stylesheet" href="css/tab.css" type="text/css" >
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>
<ul id="nav">
        <li><a href="index.php">Home</a></li>
        
		<li><a href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="nseasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               

                <li><a href="pg2.php"><i>Contact us</i></a></li>
				<li><a href="ourclients.php"><i>Feedback</i></a></li>
                   
         </li>
		 <li  class="current"><a href="login.php"><i>Login</i></a></li>
		 <li><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
	</ul>

	<div id="terms">
	 <div id="where">
   <p id="where1">
Login
	</p>
	</div>
	<div id="client">
   <form action="login.php" method="post" enctype="multpart/form-data">
<center>

<table>

<tr>
<td>Email Address
<td><input type="email" name="email3" required><br><br>

<tr>
<td>Password

<td><input type="password" name="pass" required autocomplete="off"/><br><br>
<input type="hidden" name="hid1" value="<?php if(empty($_GET['hid'])){echo "";}else{echo $_GET['hid'];}?>">
<tr>
<td colspan=2><center><input type="submit" name="login" value="submit">
</table>
</center>
</form>

   </div>
   </div>
   <div id="links">
<a href="about.php"><div id="social"><span>Connect with us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
 <div id="footer1">Copyright @ 2016-2017.The Plants Villa. All rights reserved. </div>
 
	
   
	</div>
	
	
	</body>
	</html>
<?php

   if($_SERVER["REQUEST_METHOD"] == "POST") {
      $myusername = mysqli_real_escape_string($con,$_POST['email3']);
      $mypassword = mysqli_real_escape_string($con,$_POST['pass']); 
      $hid_tmp = mysqli_real_escape_string($con,$_POST['hid1']);
      $sql = "SELECT id FROM customers WHERE email = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
	  $sql1 = "SELECT id FROM customers WHERE email = '$myusername'";
      $result1 = mysqli_query($con,$sql1);
      $row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC);

      
      $count1 = mysqli_num_rows($result1);
      if($count1 == 0)
	  {echo "<script>alert('Invalid Email')</script>";}
		
      else if($count == 1) {
				echo "<script>alert('Login Sucessful')</script>";
				session_start();
				$_SESSION['firstMessage'] = $myusername;
				$_SESSION['secondMessage'] = $hid_tmp;
				echo "<script>window.open('order.php','_self')</script>";
      }else {
				echo "<script>alert('Invalid Password')</script>";
      }
   }
?>

