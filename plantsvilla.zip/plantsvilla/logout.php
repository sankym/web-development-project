
<!DOCTYPE>
<?php 
session_start();
include('functions/include.php');
session_destroy();
echo "<script>window.open('index.php','_self')</script>"
?>