<html>
<head>
<title>decoratives</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
<script src="tabcontent.js" type="text/javascript"></script>
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>
<ul id="nav">
        <li ><a href="index.php">Home</a></li>
             <!--<li><a href="services.php"><i>Services</i></a></li>-->
		<li class="current"><a  href="#"><i>Our Products</i></a>
                    <ul>
                        <li><a href="#"><i>Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="annual.php"><i>Annual</i></a></li>
						<li><a href="aquatic.php"><i>Aquatic</i></a></li>
						<li><a href="decoratives.php"><i>Decoratives</i></a></li>   <!--new page-->


                    </ul>
						</li>
                        <li><a href="#"><i>Non Flowering</i></a>
						 <ul>

                        <li><a href="seasonal.php"><i>Seasonal</i></a></li>
                        <li><a href="nannual.php"><i>Annual</i></a></li>
                        <li><a href="naquatic.php"><i>Aquatic</i></a></li>
						<li><a href="ndecoratives.php"><i>Decoratives</i></a></li>		<!--new page-->
						

                    </ul>

						</li>
                        <li><a href="#"><i>For</i></a>
						 <ul>
                        
                        <li><a href="office.php"><i>Office</i></a></li>
                        <li><a href="house.php"><i>Home</i></a></li>
                        

                    </ul>
		
			
						</li>

                    </ul>
         </li>

		<li><a href="events.php"><i>Sale</i></a></li>
               

                <li><a href="pg2.php"><i>Contact us</i></a></li>
				<li><a href="ourclients.php"><i>Feedback</i></a></li>
		
                   
         </li>
		 <li><a href="login.php"><i>Login</i></a></li>
		 <li><a href="signup.php"><i>Sign Up</i></a></li>
		  <li><a href="expertise.php"><i>Expertise</i></a></li>
		 <!--<li class="current"style="float : right"><i><a href="logout.php">Log Out</a></i></li>-->
	</ul>


	<div id="menu1">
<div id="title">
   <p id="where1">
   Decoratives
	</p>
   </div>

       
        <div class="tabcontents">
            <div id="view1">
              <div class="img">
			  <form action="login.php" method="GET">
						 <a href=""><img src="img/seasonal/dec1.jpg" width="250" height="210"></a>
						 <div class="desc"><center>Big Pebbles Grey-Rs 12<br>
						   <input type="hidden" name="hid" value="22">
						 <input type="submit" name="steam_rice" value="Order"></center></div></form>
						 
						 
						</div>
						<div class="img">
						
			  <form action="login.php" method="GET">
						 <a href=""><img src="img/seasonal/dec2.jpg" width="250" height="210"></a>
						 <div class="desc"><center>Polished Black-Rs 30<br>
						   <input type="hidden" name="hid" value="23">
						 <input type="submit" name="jeera_rice" value="Order"></center></div></form>
						</div>
						<div class="img">
						  <form action="login.php" method="GET">
						 <a href=""><img src="img/seasonal/dec3.jpg" width="250" height="210"></a>
						 <div class="desc"><center>Polished Grey-Rs 50<br>
						   <input type="hidden" name="hid" value="24">
						 <input type="submit" name="simple_rice" value="Order"></center></div></form>
						</div>
						<div class="img">
						  <form action="login.php" method="GET">
						 <a href=""><img src="img/seasonal/dec4.jpg" width="250" height="210"></a>
						 <div class="desc"><center>Big Pebbles White-Rs 560<br>
						   <input type="hidden" name="hid" value="25">
						 <input type="submit" name="veg_biryani" value="Order"></center></div></form>
						</div>
						<div class="img">
						  <form action="login.php" method="GET">
						 <a href=""><img src="img/seasonal/dec5.jpg" width="250" height="210"></a>
						 <div class="desc"><center>Polished White-Rs 340<br>
						   <input type="hidden" name="hid" value="26">
						 <input type="submit" name="veg_biryani" value="Order"></center></div></form>
						</div>
						<div class="img">
						  <form action="login.php" method="GET">
						 <a href=""><img src="img/seasonal/dec1.jpg" width="250" height="210"></a>
						 <div class="desc"><center>Garden Pebbles-Rs 347<br>
						   <input type="hidden" name="hid" value="27">
						 <input type="submit" name="veg_biryani" value="Order"></center></div></form>
						</div>
										
			 </div>
			
		  </div>
		   <ul class="tabs" data-persist="true">
            <li><a href="#view1">Decoratives</a></li>
            
     
        </ul>
		
		
 </div>

<div id="links">
<a href="about.php"><div id="social"><span>Know About us</span></div></a>
<a href="pg2.php">
<div id="leftlinks">
<span>Contact Us</span></div></a>
<a href="termsandconditions.php">
<div id="rightlinks">
<span>Terms & Conditions</span></div></a>

</div>
<div id="footer1">Copyright @ 2016-2017.The Plants Villa. All rights reserved. </div>
	</div>

</body>
</html>
