<!DOCTYPE>
<?php 
include('functions/include.php');
?>
<html>
<head><title>Logged In</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body>
<?php
session_start();
$myusername = $_SESSION['Message1'];
$sql = mysqli_query($con,"SELECT fname FROM admin WHERE email = '$myusername'");
$result = mysqli_fetch_row($sql);
echo "Admin ";
echo $result[0];
?>
<br>
<ul id="nav">
<li class="current"><a href="admin.php">Orders</a></li>
<li><a href="adminqueries.php">Queries</a></li>
<li><a href="logout.php">Logout</a><li>
</ul>
<center>
<h1><center> Orders</center></h1>

<?php

$result = mysqli_query($con,"SELECT * FROM orders order by o_id DESC");

echo "<table border='1'>
<tr>
<th>Order Id</th>
<th>Product Id</th>
<th>Customers Email</th>
<th>Phone No</th>
<th>Quantity</th>
<th>Price</th>
<th>Total Price</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['o_id'] . "</td>";
echo "<td>" . $row['p_id'] . "</td>";
echo "<td>" . $row['c_email'] . "</td>";
echo "<td>" . $row['c_phone_no'] . "</td>";
echo "<td>" . $row['quantity'] . "</td>";
echo "<td>" . $row['price'] . "</td>";
echo "<td>" . $row['total_price'] . "</td>";
echo "</tr>";
}
echo "</table>";

mysqli_close($con);
?>

</center>




</body>
</html>
