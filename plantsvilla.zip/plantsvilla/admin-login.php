<!DOCTYPE html>
<?php 
include('functions/include.php');
?>
<html>
<head>
<title>Admin login</title>

<link rel="stylesheet" href="css/style.css" type="text/css" >
<link rel="stylesheet" href="css/aboutus.css" type="text/css" >
<link rel="stylesheet" href="css/final1.css" type="text/css" >
<link rel="stylesheet" href="css/menu1.css" type="text/css" >
<link rel="stylesheet" href="css/packages.css" type="text/css" >
<link rel="stylesheet" href="css/tab.css" type="text/css" >
</head>
<body >
<div class="example" >
<div id="head" style="margin : 1em auto;text-align :center; ">
<img src="img/logo.jpg" style="
    margin: auto;" width="600px" height="150px"/>
</div>

	<div id="terms">
	 <div id="where">
   <p id="where1">
Admin Login
	</p>
	</div>
	<div id="client">
   <form action="admin-login.php" method="post" enctype="multpart/form-data">
<center>

<table>

<tr>
<td>Email Address
<td><input type="email" name="e3" required><br><br>

<tr>
<td>Password

<td><input type="password" name="pass1" required autocomplete="off"/><br><br>
<tr>
<td colspan=2><center><input type="submit" name="adminlogin" value="submit">
</table>
</center>
</form>

   </div>

</div>
 <div id="footer1">Copyright @ 2016-2017.The Plants Villa. All rights reserved. </div>
 
	
   
	</div>
	
	
	</body>
	</html>
<?php

   if($_SERVER["REQUEST_METHOD"] == "POST") {
      $myusername = mysqli_real_escape_string($con,$_POST['e3']);
      $mypassword = mysqli_real_escape_string($con,$_POST['pass1']); 
      $sql = "SELECT a_id FROM admin WHERE email = '$myusername' and password = '$mypassword'";
      $result = mysqli_query($con,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
	  $sql1 = "SELECT a_id FROM admin WHERE email = '$myusername'";
      $result1 = mysqli_query($con,$sql1);
      $row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC);

      
      $count1 = mysqli_num_rows($result1);
      if($count1 == 0)
	  {echo "<script>alert('Invalid Email')</script>";}
		
      else if($count == 1) {
				echo "<script>alert('Login Sucessful')</script>";
				session_start();
				$_SESSION['Message1'] = $myusername;
				echo "<script>window.open('admin.php','_self')</script>";
      }else {
				echo "<script>alert('Invalid Password')</script>";
      }
   }
?>

