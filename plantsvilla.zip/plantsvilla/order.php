<!DOCTYPE>
<?php 
include('functions/include.php');
?>
<html>
<head><title>Order</title>
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/aboutus.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/final1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/menu1.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/packages.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/tab.css" type="text/css" media="screen">
</head>
<body>
<?php
session_start();
$myusername = $_SESSION['firstMessage'];
$sql = mysqli_query($con,"SELECT fname FROM customers WHERE email = '$myusername'");
$result = mysqli_fetch_row($sql);
echo "Welcome ";
echo $result[0];
?>
<br>
<ul id="nav">
<li class="current"><a href="order.php">Order</a>
<li><a href="loggedin.php">Queries</a>
<li><a href="logout.php">logout</a>
</ul>
<form action="order.php" method="post" enctype="multpart/form-data">
<center>
<h1><center> Order </center></h1>
<table>

<tr>

<td>Product ID

<td><input type="text" name="pid1" value="<?php  $id=$_SESSION['secondMessage']; echo $id; ?>"required><br><br>
<tr>

<tr>
<td>Quantity
<td><input type="text" name="quantity1" required><br><br>





<tr>
<td colspan="2"><center><input type="submit" name="in_post" value="Send">
</table>
</center>
</form>



</body>
</html>
<?php

	if(isset($_POST['in_post'])){
	$p_tmp = $_POST['pid1'];
	$quan_tmp = $_POST['quantity1'];
	$myusername = $_SESSION['firstMessage'];
	$sql = mysqli_query($con,"SELECT phone_no FROM customers WHERE email = '$myusername'");
	$result = mysqli_fetch_row($sql);
	$sql1 = mysqli_query($con,"SELECT price FROM products WHERE id = '$p_tmp'");
	$result1 = mysqli_fetch_row($sql1);
	$res=$result1[0]*$quan_tmp;
	$insert_qu = "insert into orders (p_id,c_email,c_phone_no,quantity,price,total_price)
	values('$p_tmp','$myusername','$result[0]','$quan_tmp','$result1[0]','$res')";
	
	$insert_q = mysqli_query($con, $insert_qu);
	if($insert_q){
		
		echo "<script>alert('Order Successful!We will Contact You Soon')</script>";
		echo "<script>alert('Total Price = Rs $res')</script>";
		echo "<script>window.open('order.php','_self')</script>";
	}
	}
?>